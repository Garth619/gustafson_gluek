# WordPress MySQL database migration
#
# Generated: Monday 12. December 2016 16:19 UTC
# Hostname: localhost
# Database: `gus`
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2016-12-01 22:35:37', '2016-12-01 22:35:37', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, 'post-trashed', '', '', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=563 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://gus.com', 'yes'),
(2, 'home', 'http://gus.com', 'yes'),
(3, 'blogname', 'Gustaphson and Gluek', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'garrett@1point21interactive.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '1', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'closed', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'm.d.y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '1', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:91:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=4&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:3:{i:0;s:29:"gravityforms/gravityforms.php";i:1;s:37:"post-types-order/post-types-order.php";i:2;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'gustafsonandgluek', 'yes'),
(41, 'stylesheet', 'gustafsonandgluek', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '1', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:3:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}i:3;a:4:{s:5:"title";s:10:"Categories";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '18', 'yes'),
(84, 'page_on_front', '4', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '37965', 'yes'),
(92, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_archives', 'a:3:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}i:3;a:3:{s:5:"title";s:5:"Month";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'sidebars_widgets', 'a:5:{s:19:"primary-widget-area";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:19:"wp_inactive_widgets";a:0:{}s:12:"archive-area";a:1:{i:0;s:10:"archives-3";}s:13:"category-area";a:1:{i:0;s:12:"categories-3";}s:13:"array_version";i:3;}', 'yes'),
(99, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'cron', 'a:6:{i:1481560723;a:1:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1481569750;a:1:{s:17:"gravityforms_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1481582138;a:2:{s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1481582198;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1481582775;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(135, 'theme_mods_twentysixteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1480632203;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(136, 'current_theme', 'Gustafson and Gluek', 'yes'),
(137, 'theme_mods_gustafsonandgluek', 'a:3:{i:0;b:0;s:18:"custom_css_post_id";i:-1;s:18:"nav_menu_locations";a:1:{s:7:"primary";i:2;}}', 'yes'),
(138, 'theme_switched', '', 'yes'),
(171, 'recently_activated', 'a:0:{}', 'yes'),
(172, 'wpmdb_settings', 'a:7:{s:11:"max_request";i:1048576;s:3:"key";s:32:"tQCYykm0oEFgzXhVCq7/EljIJCczHbX0";s:10:"allow_pull";b:0;s:10:"allow_push";b:0;s:8:"profiles";a:0:{}s:7:"licence";s:0:"";s:10:"verify_ssl";b:0;}', 'yes'),
(197, 'widget_gform_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(198, 'rg_form_version', '2.1.1', 'yes'),
(201, 'rg_gforms_key', '621e21584ab7936611e0d28422299c97', 'yes'),
(202, 'rg_gforms_disable_css', '1', 'yes'),
(203, 'rg_gforms_enable_html5', '0', 'yes'),
(204, 'gform_enable_noconflict', '0', 'yes'),
(205, 'rg_gforms_enable_akismet', '', 'yes'),
(206, 'rg_gforms_captcha_public_key', '', 'yes'),
(207, 'rg_gforms_captcha_private_key', '', 'yes'),
(208, 'rg_gforms_currency', 'USD', 'yes'),
(209, 'rg_gforms_message', '<!--GFM-->', 'yes'),
(216, 'gravityformsaddon_gravityformswebapi_version', '1.0', 'yes'),
(302, 'db_upgraded', '', 'yes'),
(305, 'can_compress_scripts', '1', 'no'),
(308, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(360, 'WPLANG', '', 'yes'),
(364, 'fresh_site', '0', 'yes'),
(475, 'cpto_options', 'a:6:{s:23:"show_reorder_interfaces";a:2:{s:4:"post";s:4:"show";s:10:"attachment";s:4:"show";}s:8:"autosort";i:1;s:9:"adminsort";i:1;s:17:"archive_drag_drop";i:1;s:10:"capability";s:13:"switch_themes";s:21:"navigation_sort_apply";i:1;}', 'yes'),
(476, 'CPT_configured', 'TRUE', 'yes'),
(515, 'category_children', 'a:0:{}', 'yes') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 4, '_edit_last', '1'),
(3, 4, '_edit_lock', '1481128520:1'),
(4, 4, '_wp_page_template', 'page-main.php'),
(5, 2, '_wp_trash_meta_status', 'publish'),
(6, 2, '_wp_trash_meta_time', '1481128500'),
(7, 2, '_wp_desired_post_slug', 'sample-page'),
(8, 8, '_edit_last', '1'),
(9, 8, '_wp_page_template', 'default'),
(10, 8, '_edit_lock', '1481128393:1'),
(11, 10, '_edit_last', '1'),
(12, 10, '_wp_page_template', 'page-practiceareas.php'),
(13, 10, '_edit_lock', '1481510451:1'),
(14, 12, '_edit_last', '1'),
(15, 12, '_wp_page_template', 'default'),
(16, 12, '_edit_lock', '1481128462:1'),
(17, 14, '_edit_last', '1'),
(18, 14, '_wp_page_template', 'default'),
(19, 14, '_edit_lock', '1481128486:1'),
(20, 16, '_edit_last', '1'),
(21, 16, '_wp_page_template', 'default'),
(22, 16, '_edit_lock', '1481128549:1'),
(23, 18, '_edit_last', '1'),
(24, 18, '_wp_page_template', 'default'),
(25, 18, '_edit_lock', '1481128567:1'),
(26, 20, '_menu_item_type', 'post_type'),
(27, 20, '_menu_item_menu_item_parent', '0'),
(28, 20, '_menu_item_object_id', '4'),
(29, 20, '_menu_item_object', 'page'),
(30, 20, '_menu_item_target', ''),
(31, 20, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(32, 20, '_menu_item_xfn', ''),
(33, 20, '_menu_item_url', ''),
(35, 21, '_menu_item_type', 'post_type'),
(36, 21, '_menu_item_menu_item_parent', '0'),
(37, 21, '_menu_item_object_id', '8'),
(38, 21, '_menu_item_object', 'page'),
(39, 21, '_menu_item_target', ''),
(40, 21, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(41, 21, '_menu_item_xfn', ''),
(42, 21, '_menu_item_url', ''),
(44, 22, '_menu_item_type', 'post_type'),
(45, 22, '_menu_item_menu_item_parent', '0'),
(46, 22, '_menu_item_object_id', '14'),
(47, 22, '_menu_item_object', 'page'),
(48, 22, '_menu_item_target', ''),
(49, 22, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(50, 22, '_menu_item_xfn', ''),
(51, 22, '_menu_item_url', ''),
(53, 23, '_menu_item_type', 'post_type'),
(54, 23, '_menu_item_menu_item_parent', '0'),
(55, 23, '_menu_item_object_id', '12'),
(56, 23, '_menu_item_object', 'page'),
(57, 23, '_menu_item_target', ''),
(58, 23, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(59, 23, '_menu_item_xfn', ''),
(60, 23, '_menu_item_url', ''),
(62, 24, '_menu_item_type', 'post_type'),
(63, 24, '_menu_item_menu_item_parent', '0'),
(64, 24, '_menu_item_object_id', '4'),
(65, 24, '_menu_item_object', 'page'),
(66, 24, '_menu_item_target', ''),
(67, 24, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(68, 24, '_menu_item_xfn', ''),
(69, 24, '_menu_item_url', ''),
(70, 24, '_menu_item_orphaned', '1481129866'),
(71, 25, '_menu_item_type', 'post_type'),
(72, 25, '_menu_item_menu_item_parent', '0'),
(73, 25, '_menu_item_object_id', '18'),
(74, 25, '_menu_item_object', 'page'),
(75, 25, '_menu_item_target', ''),
(76, 25, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(77, 25, '_menu_item_xfn', ''),
(78, 25, '_menu_item_url', ''),
(80, 26, '_menu_item_type', 'post_type'),
(81, 26, '_menu_item_menu_item_parent', '0'),
(82, 26, '_menu_item_object_id', '10'),
(83, 26, '_menu_item_object', 'page'),
(84, 26, '_menu_item_target', ''),
(85, 26, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(86, 26, '_menu_item_xfn', ''),
(87, 26, '_menu_item_url', ''),
(89, 27, '_menu_item_type', 'post_type'),
(90, 27, '_menu_item_menu_item_parent', '0'),
(91, 27, '_menu_item_object_id', '16'),
(92, 27, '_menu_item_object', 'page'),
(93, 27, '_menu_item_target', ''),
(94, 27, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(95, 27, '_menu_item_xfn', ''),
(96, 27, '_menu_item_url', ''),
(98, 28, '_edit_last', '1'),
(99, 28, '_edit_lock', '1481326411:1'),
(100, 28, '_wp_page_template', 'default'),
(101, 32, '_edit_last', '1'),
(102, 32, '_wp_page_template', 'default'),
(103, 32, '_edit_lock', '1481498917:1'),
(104, 32, '_wp_trash_meta_status', 'publish'),
(105, 32, '_wp_trash_meta_time', '1481499296'),
(106, 32, '_wp_desired_post_slug', 'blog'),
(107, 34, '_edit_last', '1') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(108, 34, '_edit_lock', '1481502886:1'),
(111, 36, '_edit_last', '1'),
(112, 36, '_edit_lock', '1481504645:1'),
(115, 38, '_edit_last', '1'),
(116, 38, '_edit_lock', '1481504453:1'),
(119, 40, '_edit_last', '1'),
(120, 40, '_edit_lock', '1481502258:1'),
(125, 1, '_wp_trash_meta_status', 'publish'),
(126, 1, '_wp_trash_meta_time', '1481501763'),
(127, 1, '_wp_desired_post_slug', 'hello-world'),
(128, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:"1";}') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2016-12-01 22:35:37', '2016-12-01 22:35:37', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world__trashed', '', '', '2016-12-12 00:16:03', '2016-12-12 00:16:03', '', 0, 'http://gus.com/?p=1', 4, 'post', '', 1),
(2, 1, '2016-12-01 22:35:37', '2016-12-01 22:35:37', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://gus.com/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'trash', 'closed', 'open', '', 'sample-page__trashed', '', '', '2016-12-07 16:35:00', '2016-12-07 16:35:00', '', 0, 'http://gus.com/?page_id=2', 0, 'page', '', 0),
(4, 1, '2016-12-01 22:46:26', '2016-12-01 22:46:26', '', 'Home', '', 'publish', 'closed', 'closed', '', 'main', '', '', '2016-12-07 16:35:20', '2016-12-07 16:35:20', '', 0, 'http://gus.com/?page_id=4', 0, 'page', '', 0),
(5, 1, '2016-12-01 22:46:26', '2016-12-01 22:46:26', '', 'Main', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2016-12-01 22:46:26', '2016-12-01 22:46:26', '', 4, 'http://gus.com/2016/12/01/4-revision-v1/', 0, 'revision', '', 0),
(6, 1, '2016-12-07 16:35:00', '2016-12-07 16:35:00', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://gus.com/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2016-12-07 16:35:00', '2016-12-07 16:35:00', '', 2, 'http://gus.com/2016/12/07/2-revision-v1/', 0, 'revision', '', 0),
(7, 1, '2016-12-07 16:35:20', '2016-12-07 16:35:20', '', 'Home', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2016-12-07 16:35:20', '2016-12-07 16:35:20', '', 4, 'http://gus.com/2016/12/07/4-revision-v1/', 0, 'revision', '', 0),
(8, 1, '2016-12-07 16:35:33', '2016-12-07 16:35:33', '', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2016-12-07 16:35:33', '2016-12-07 16:35:33', '', 0, 'http://gus.com/?page_id=8', 0, 'page', '', 0),
(9, 1, '2016-12-07 16:35:33', '2016-12-07 16:35:33', '', 'About', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2016-12-07 16:35:33', '2016-12-07 16:35:33', '', 8, 'http://gus.com/2016/12/07/8-revision-v1/', 0, 'revision', '', 0),
(10, 1, '2016-12-07 16:35:46', '2016-12-07 16:35:46', '', 'Practice Areas', '', 'publish', 'closed', 'closed', '', 'practice-areas', '', '', '2016-12-12 02:43:09', '2016-12-12 02:43:09', '', 0, 'http://gus.com/?page_id=10', 0, 'page', '', 0),
(11, 1, '2016-12-07 16:35:46', '2016-12-07 16:35:46', '', 'Practice Areas', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2016-12-07 16:35:46', '2016-12-07 16:35:46', '', 10, 'http://gus.com/2016/12/07/10-revision-v1/', 0, 'revision', '', 0),
(12, 1, '2016-12-07 16:36:03', '2016-12-07 16:36:03', '', 'Current Investigations', '', 'publish', 'closed', 'closed', '', 'current-investigations', '', '', '2016-12-07 16:36:42', '2016-12-07 16:36:42', '', 0, 'http://gus.com/?page_id=12', 0, 'page', '', 0),
(13, 1, '2016-12-07 16:36:03', '2016-12-07 16:36:03', '', 'Current Investigations', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2016-12-07 16:36:03', '2016-12-07 16:36:03', '', 12, 'http://gus.com/2016/12/07/12-revision-v1/', 0, 'revision', '', 0),
(14, 1, '2016-12-07 16:37:06', '2016-12-07 16:37:06', '', 'Case Results', '', 'publish', 'closed', 'closed', '', 'case-results', '', '', '2016-12-07 16:37:06', '2016-12-07 16:37:06', '', 0, 'http://gus.com/?page_id=14', 0, 'page', '', 0),
(15, 1, '2016-12-07 16:37:06', '2016-12-07 16:37:06', '', 'Case Results', '', 'inherit', 'closed', 'closed', '', '14-revision-v1', '', '', '2016-12-07 16:37:06', '2016-12-07 16:37:06', '', 14, 'http://gus.com/2016/12/07/14-revision-v1/', 0, 'revision', '', 0),
(16, 1, '2016-12-07 16:37:55', '2016-12-07 16:37:55', '', 'Testimonials', '', 'publish', 'closed', 'closed', '', 'testimonials', '', '', '2016-12-07 16:37:55', '2016-12-07 16:37:55', '', 0, 'http://gus.com/?page_id=16', 0, 'page', '', 0),
(17, 1, '2016-12-07 16:37:55', '2016-12-07 16:37:55', '', 'Testimonials', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2016-12-07 16:37:55', '2016-12-07 16:37:55', '', 16, 'http://gus.com/2016/12/07/16-revision-v1/', 0, 'revision', '', 0),
(18, 1, '2016-12-07 16:38:22', '2016-12-07 16:38:22', '', 'Latest News', '', 'publish', 'closed', 'closed', '', 'latest-news', '', '', '2016-12-07 16:38:22', '2016-12-07 16:38:22', '', 0, 'http://gus.com/?page_id=18', 0, 'page', '', 0),
(19, 1, '2016-12-07 16:38:22', '2016-12-07 16:38:22', '', 'Latest News', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2016-12-07 16:38:22', '2016-12-07 16:38:22', '', 18, 'http://gus.com/2016/12/07/18-revision-v1/', 0, 'revision', '', 0),
(20, 1, '2016-12-07 16:58:39', '2016-12-07 16:58:39', ' ', '', '', 'publish', 'closed', 'closed', '', '20', '', '', '2016-12-07 16:58:45', '2016-12-07 16:58:45', '', 0, 'http://gus.com/?p=20', 1, 'nav_menu_item', '', 0),
(21, 1, '2016-12-07 16:58:39', '2016-12-07 16:58:39', ' ', '', '', 'publish', 'closed', 'closed', '', '21', '', '', '2016-12-07 16:58:45', '2016-12-07 16:58:45', '', 0, 'http://gus.com/?p=21', 2, 'nav_menu_item', '', 0),
(22, 1, '2016-12-07 16:58:39', '2016-12-07 16:58:39', ' ', '', '', 'publish', 'closed', 'closed', '', '22', '', '', '2016-12-07 16:58:45', '2016-12-07 16:58:45', '', 0, 'http://gus.com/?p=22', 5, 'nav_menu_item', '', 0),
(23, 1, '2016-12-07 16:58:39', '2016-12-07 16:58:39', ' ', '', '', 'publish', 'closed', 'closed', '', '23', '', '', '2016-12-07 16:58:45', '2016-12-07 16:58:45', '', 0, 'http://gus.com/?p=23', 4, 'nav_menu_item', '', 0),
(24, 1, '2016-12-07 16:57:46', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-12-07 16:57:46', '0000-00-00 00:00:00', '', 0, 'http://gus.com/?p=24', 1, 'nav_menu_item', '', 0),
(25, 1, '2016-12-07 16:58:40', '2016-12-07 16:58:40', ' ', '', '', 'publish', 'closed', 'closed', '', '25', '', '', '2016-12-07 16:58:45', '2016-12-07 16:58:45', '', 0, 'http://gus.com/?p=25', 7, 'nav_menu_item', '', 0),
(26, 1, '2016-12-07 16:58:39', '2016-12-07 16:58:39', ' ', '', '', 'publish', 'closed', 'closed', '', '26', '', '', '2016-12-07 16:58:45', '2016-12-07 16:58:45', '', 0, 'http://gus.com/?p=26', 3, 'nav_menu_item', '', 0),
(27, 1, '2016-12-07 16:58:40', '2016-12-07 16:58:40', ' ', '', '', 'publish', 'closed', 'closed', '', '27', '', '', '2016-12-07 16:58:45', '2016-12-07 16:58:45', '', 0, 'http://gus.com/?p=27', 6, 'nav_menu_item', '', 0),
(28, 1, '2016-12-09 22:06:09', '2016-12-09 22:06:09', '<h2>H2 Styling - LOREM USOUM DOLURITS</h2>\r\nNulla sagittis eleifend tellus, et <a href="http://facebook.com">ultrices massa</a> rutrum id. Maecenas justo augue, commodo nec est ac, tincidunt egestas diam. Class aptent taciti sociosqu ad litora torquent per embedded link per inceptos himenaeos. Donec placerat sed metus ut mollis. Vestibulum vel semper justo. Sed leo tortor, faucibus eget congue id, sollicitudin varius dui. Praesent blandit elit vehicula tortor suscipit cursus. Pellentesque pellentesque bibendum aliquam. Suspendisse fermentum sagittis mauris, sit amet aliquam quam gravida et. Vivamus non mollis enim.\r\n<h3>H3 Styling - Lorem Ispum Dolor ague comondo diam aptenet amet sit quisque</h3>\r\nMaecenas justo augue, commodo nec est ac, tincidunt egestas diam. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Donec placerat sed metus ut mollis. Vestibulum vel semper justo. Sed leo tortor, faucibus eget congue id, sollicitudin varius dui. Praesent blandit elit vehicula tortor suscipit cursus. Pellentesque pellentesque bibendum aliquam. Suspendisse fermentum sagittis mauris, sit amet aliquam quam gravida et. Vivamus non mollis enim. Cras quis mattis ex. Quisque quam arcu, lacinia at metus nec. Maecenas justo augue, commodo nec est ac, tincidunt egestas diam. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Donec placerat sed metus ut mollis. Vestibulum vel semper justo. Sed leo tortor, faucibus eget congue id, sollicitudin varius dui. Praesent blandit elit vehicula tortor suscipit cursus. Pellentesque pellentesque bibendum aliquam. Suspendisse fermentum sagittis mauris, sit amet aliquam quam gravida et. Vivamus non mollis enim. Cras quis mattis ex. Quisque quam arcu, lacinia at metus nec.\r\n<h4>H4 Styling</h4>\r\n<ul>\r\n 	<li>St. Barnabas Hospital, Inc., et al. v. Lundbeck, Inc. (D. Minn.)</li>\r\n 	<li>In re Comcast Corp. Set-Top Cable Television Box Antitrust Litig. (E.D. Pa.)</li>\r\n 	<li>In re DRAM Antitrust Litig. (N.D. Cal. and multiple state court actions)</li>\r\n 	<li>In re Medtronic, Inc., Implantable Defibrillators Prod. Liab. Litig. (D. Minn.)</li>\r\n 	<li>In re Medtronic, Inc., Sprint Fidelis Leads Prod. Liab. Litig. (D. Minn.)</li>\r\n 	<li>In re National Arbitration Forum Litig. (D. Minn.)</li>\r\n</ul>\r\n<h2>H2 Styling - LOREM USOUM DOLURITS</h2>\r\nMaecenas justo augue, commodo nec est ac, tincidunt egestas diam. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Donec placerat sed metus ut mollis. Vestibulum vel semper justo. Sed leo tortor, faucibus eget congue id, sollicitudin varius dui. Praesent blandit elit vehicula tortor suscipit cursus. Pellentesque pellentesque bibendum aliquam. Suspendisse fermentum sagittis mauris, sit amet aliquam quam gravida et. Vivamus non mollis enim. Cras quis mattis ex. Quisque quam arcu, lacinia at metus nec. Maecenas justo augue, commodo nec est ac, tincidunt egestas diam. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Donec placerat sed metus ut mollis. Vestibulum vel semper justo. Sed leo tortor, faucibus eget congue id, sollicitudin varius dui. Praesent blandit elit vehicula tortor suscipit cursus. Pellentesque pellentesque bibendum aliquam. Suspendisse fermentum sagittis mauris, sit amet aliquam quam gravida et. Vivamus non mollis enim. Cras quis mattis ex. Quisque quam arcu, lacinia at metus nec.', 'Inner Page Styles', '', 'publish', 'closed', 'closed', '', 'inner-page-styles', '', '', '2016-12-09 23:35:49', '2016-12-09 23:35:49', '', 0, 'http://gus.com/?page_id=28', 0, 'page', '', 0),
(29, 1, '2016-12-09 22:06:09', '2016-12-09 22:06:09', '<h2>H2 Styling - LOREM USOUM DOLURITS</h2>\r\nNulla sagittis eleifend tellus, et ultrices massa rutrum id. Maecenas justo augue, commodo nec est ac, tincidunt egestas diam. Class aptent taciti sociosqu ad litora torquent per embedded link per inceptos himenaeos. Donec placerat sed metus ut mollis. Vestibulum vel semper justo. Sed leo tortor, faucibus eget congue id, sollicitudin varius dui. Praesent blandit elit vehicula tortor suscipit cursus. Pellentesque pellentesque bibendum aliquam. Suspendisse fermentum sagittis mauris, sit amet aliquam quam gravida et. Vivamus non mollis enim.\r\n<h3>H3 Styling - Lorem Ispum Dolor ague comondo diam aptenet amet sit quisque</h3>\r\nMaecenas justo augue, commodo nec est ac, tincidunt egestas diam. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Donec placerat sed metus ut mollis. Vestibulum vel semper justo. Sed leo tortor, faucibus eget congue id, sollicitudin varius dui. Praesent blandit elit vehicula tortor suscipit cursus. Pellentesque pellentesque bibendum aliquam. Suspendisse fermentum sagittis mauris, sit amet aliquam quam gravida et. Vivamus non mollis enim. Cras quis mattis ex. Quisque quam arcu, lacinia at metus nec. Maecenas justo augue, commodo nec est ac, tincidunt egestas diam. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Donec placerat sed metus ut mollis. Vestibulum vel semper justo. Sed leo tortor, faucibus eget congue id, sollicitudin varius dui. Praesent blandit elit vehicula tortor suscipit cursus. Pellentesque pellentesque bibendum aliquam. Suspendisse fermentum sagittis mauris, sit amet aliquam quam gravida et. Vivamus non mollis enim. Cras quis mattis ex. Quisque quam arcu, lacinia at metus nec.\r\n<h4>H4 Styling</h4>\r\n<ul>\r\n 	<li>St. Barnabas Hospital, Inc., et al. v. Lundbeck, Inc. (D. Minn.)</li>\r\n 	<li>\r\nIn re Comcast Corp. Set-Top Cable Television Box Antitrust Litig. (E.D. Pa.)</li>\r\n 	<li>\r\nIn re DRAM Antitrust Litig. (N.D. Cal. and multiple state court actions)</li>\r\n 	<li>\r\nIn re Medtronic, Inc., Implantable Defibrillators Prod. Liab. Litig. (D. Minn.)</li>\r\n 	<li>\r\nIn re Medtronic, Inc., Sprint Fidelis Leads Prod. Liab. Litig. (D. Minn.)</li>\r\n 	<li>\r\nIn re National Arbitration Forum Litig. (D. Minn.)</li>\r\n</ul>\r\n<h2>H2 Styling - LOREM USOUM DOLURITS</h2>\r\nMaecenas justo augue, commodo nec est ac, tincidunt egestas diam. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Donec placerat sed metus ut mollis. Vestibulum vel semper justo. Sed leo tortor, faucibus eget congue id, sollicitudin varius dui. Praesent blandit elit vehicula tortor suscipit cursus. Pellentesque pellentesque bibendum aliquam. Suspendisse fermentum sagittis mauris, sit amet aliquam quam gravida et. Vivamus non mollis enim. Cras quis mattis ex. Quisque quam arcu, lacinia at metus nec. Maecenas justo augue, commodo nec est ac, tincidunt egestas diam. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Donec placerat sed metus ut mollis. Vestibulum vel semper justo. Sed leo tortor, faucibus eget congue id, sollicitudin varius dui. Praesent blandit elit vehicula tortor suscipit cursus. Pellentesque pellentesque bibendum aliquam. Suspendisse fermentum sagittis mauris, sit amet aliquam quam gravida et. Vivamus non mollis enim. Cras quis mattis ex. Quisque quam arcu, lacinia at metus nec.', 'Inner Page Styles', '', 'inherit', 'closed', 'closed', '', '28-revision-v1', '', '', '2016-12-09 22:06:09', '2016-12-09 22:06:09', '', 28, 'http://gus.com/2016/12/09/28-revision-v1/', 0, 'revision', '', 0),
(30, 1, '2016-12-09 23:35:49', '2016-12-09 23:35:49', '<h2>H2 Styling - LOREM USOUM DOLURITS</h2>\r\nNulla sagittis eleifend tellus, et <a href="http://facebook.com">ultrices massa</a> rutrum id. Maecenas justo augue, commodo nec est ac, tincidunt egestas diam. Class aptent taciti sociosqu ad litora torquent per embedded link per inceptos himenaeos. Donec placerat sed metus ut mollis. Vestibulum vel semper justo. Sed leo tortor, faucibus eget congue id, sollicitudin varius dui. Praesent blandit elit vehicula tortor suscipit cursus. Pellentesque pellentesque bibendum aliquam. Suspendisse fermentum sagittis mauris, sit amet aliquam quam gravida et. Vivamus non mollis enim.\r\n<h3>H3 Styling - Lorem Ispum Dolor ague comondo diam aptenet amet sit quisque</h3>\r\nMaecenas justo augue, commodo nec est ac, tincidunt egestas diam. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Donec placerat sed metus ut mollis. Vestibulum vel semper justo. Sed leo tortor, faucibus eget congue id, sollicitudin varius dui. Praesent blandit elit vehicula tortor suscipit cursus. Pellentesque pellentesque bibendum aliquam. Suspendisse fermentum sagittis mauris, sit amet aliquam quam gravida et. Vivamus non mollis enim. Cras quis mattis ex. Quisque quam arcu, lacinia at metus nec. Maecenas justo augue, commodo nec est ac, tincidunt egestas diam. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Donec placerat sed metus ut mollis. Vestibulum vel semper justo. Sed leo tortor, faucibus eget congue id, sollicitudin varius dui. Praesent blandit elit vehicula tortor suscipit cursus. Pellentesque pellentesque bibendum aliquam. Suspendisse fermentum sagittis mauris, sit amet aliquam quam gravida et. Vivamus non mollis enim. Cras quis mattis ex. Quisque quam arcu, lacinia at metus nec.\r\n<h4>H4 Styling</h4>\r\n<ul>\r\n 	<li>St. Barnabas Hospital, Inc., et al. v. Lundbeck, Inc. (D. Minn.)</li>\r\n 	<li>In re Comcast Corp. Set-Top Cable Television Box Antitrust Litig. (E.D. Pa.)</li>\r\n 	<li>In re DRAM Antitrust Litig. (N.D. Cal. and multiple state court actions)</li>\r\n 	<li>In re Medtronic, Inc., Implantable Defibrillators Prod. Liab. Litig. (D. Minn.)</li>\r\n 	<li>In re Medtronic, Inc., Sprint Fidelis Leads Prod. Liab. Litig. (D. Minn.)</li>\r\n 	<li>In re National Arbitration Forum Litig. (D. Minn.)</li>\r\n</ul>\r\n<h2>H2 Styling - LOREM USOUM DOLURITS</h2>\r\nMaecenas justo augue, commodo nec est ac, tincidunt egestas diam. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Donec placerat sed metus ut mollis. Vestibulum vel semper justo. Sed leo tortor, faucibus eget congue id, sollicitudin varius dui. Praesent blandit elit vehicula tortor suscipit cursus. Pellentesque pellentesque bibendum aliquam. Suspendisse fermentum sagittis mauris, sit amet aliquam quam gravida et. Vivamus non mollis enim. Cras quis mattis ex. Quisque quam arcu, lacinia at metus nec. Maecenas justo augue, commodo nec est ac, tincidunt egestas diam. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Donec placerat sed metus ut mollis. Vestibulum vel semper justo. Sed leo tortor, faucibus eget congue id, sollicitudin varius dui. Praesent blandit elit vehicula tortor suscipit cursus. Pellentesque pellentesque bibendum aliquam. Suspendisse fermentum sagittis mauris, sit amet aliquam quam gravida et. Vivamus non mollis enim. Cras quis mattis ex. Quisque quam arcu, lacinia at metus nec.', 'Inner Page Styles', '', 'inherit', 'closed', 'closed', '', '28-revision-v1', '', '', '2016-12-09 23:35:49', '2016-12-09 23:35:49', '', 28, 'http://gus.com/2016/12/09/28-revision-v1/', 0, 'revision', '', 0),
(31, 1, '2016-12-10 00:03:06', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-12-10 00:03:06', '0000-00-00 00:00:00', '', 0, 'http://gus.com/?p=31', 0, 'post', '', 0),
(32, 1, '2016-12-11 23:30:01', '2016-12-11 23:30:01', '', 'Blog', '', 'trash', 'closed', 'closed', '', 'blog__trashed', '', '', '2016-12-11 23:34:56', '2016-12-11 23:34:56', '', 0, 'http://gus.com/?page_id=32', 0, 'page', '', 0),
(33, 1, '2016-12-11 23:30:01', '2016-12-11 23:30:01', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '32-revision-v1', '', '', '2016-12-11 23:30:01', '2016-12-11 23:30:01', '', 32, 'http://gus.com/2016/12/11/32-revision-v1/', 0, 'revision', '', 0),
(34, 1, '2016-12-11 23:36:22', '2016-12-11 23:36:22', 'On Tuesday, Gustafson Gluek PLLC filed a complaint on behalf of purchasers of chicken alleging that the companies comprising 98% of the chicken meat produced in the United States conspired to fix prices for chicken. The complaint alleges a conspiracy dating back to 2008 that involved the restriction of production to increase prices. The complaint also seeks damages on behalf of a class of indirect purchasers of chicken, who purchased via a distributor.  If you purchased chicken via a distributor and would like to learn more about your potential claim, please contact us by telephone or online.', 'Poultry Price-Fixing', 'On Tuesday, Gustafson Gluek PLLC filed a complaint on behalf of purchasers of chicken alleging that the companies comprising 98% of the chicken meat produced in the United States conspired to fix prices for chicken. The complaint alleges a conspiracy dating back to 2008 that involved the restriction of production to increase prices. The complaint also seeks damages on behalf of a class of indirect purchasers of chicken, who purchased via a distributor.  If you purchased chicken via a distributor and would like to learn more about your potential claim, please contact us by telephone or online.', 'publish', 'open', 'open', '', 'poultry-price-fixing', '', '', '2016-12-12 00:34:44', '2016-12-12 00:34:44', '', 0, 'http://gus.com/?p=34', 0, 'post', '', 0),
(35, 1, '2016-12-11 23:36:22', '2016-12-11 23:36:22', 'On Tuesday, Gustafson Gluek PLLC filed a complaint on behalf of purchasers of chicken alleging that the companies comprising 98% of the chicken meat produced in the United States conspired to fix prices for chicken. The complaint alleges a conspiracy dating back to 2008 that involved the restriction of production to increase prices. The complaint also seeks damages on behalf of a class of indirect purchasers of chicken, who purchased via a distributor.  If you purchased chicken via a distributor and would like to learn more about your potential claim, please contact us by telephone or online.', 'Poultry Price-Fixing', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2016-12-11 23:36:22', '2016-12-11 23:36:22', '', 34, 'http://gus.com/2016/12/11/34-revision-v1/', 0, 'revision', '', 0),
(36, 1, '2016-12-11 23:36:50', '2016-12-11 23:36:50', 'Gustafson Gluek is investigating claims on behalf of investors in Northern Oil &amp; Gas, Inc. (NYSE: NOG) regarding whether certain officers and/or directors may have breached their fiduciary duties and/or engaged in stock manipulation, in violation of federal securities laws.\r\nThe investigation concerns the following events, among others:\r\nOn August 11, 2016, Michael Reger informed Northern Oil &amp; Gas that the SEC had issued him a Wells Notice, a preliminary recommendation for enforcement action. The notice was in connection with the SEC’s investigation of 2012 trading patterns in Dakota Plains Holding, Inc., a company Mr. Reger helped start with several partners. On August 16, 2016, Northern Oil &amp; Gas fired Mr. Reger as CEO without severance. Upon this announcement, NOG shares fell in value.\r\nIf you have purchased Northern Oil &amp; Gas shares and wish to discuss your options, or if you are aware of any facts related to this investigation, or if you want to get more information—please contact us by telephone or online.', 'Northern Oil & Gas Securities', 'Gustafson Gluek is investigating claims on behalf of investors in Northern Oil &amp; Gas, Inc. (NYSE: NOG) regarding whether certain officers and/or directors may have breached their fiduciary duties and/or engaged in stock manipulation, in violation of federal securities laws.', 'publish', 'open', 'open', '', 'northern-oil-gas-securities', '', '', '2016-12-12 00:34:54', '2016-12-12 00:34:54', '', 0, 'http://gus.com/?p=36', 1, 'post', '', 0),
(37, 1, '2016-12-11 23:36:50', '2016-12-11 23:36:50', 'Gustafson Gluek is investigating claims on behalf of investors in Northern Oil &amp; Gas, Inc. (NYSE: NOG) regarding whether certain officers and/or directors may have breached their fiduciary duties and/or engaged in stock manipulation, in violation of federal securities laws.\r\nThe investigation concerns the following events, among others:\r\nOn August 11, 2016, Michael Reger informed Northern Oil &amp; Gas that the SEC had issued him a Wells Notice, a preliminary recommendation for enforcement action. The notice was in connection with the SEC’s investigation of 2012 trading patterns in Dakota Plains Holding, Inc., a company Mr. Reger helped start with several partners. On August 16, 2016, Northern Oil &amp; Gas fired Mr. Reger as CEO without severance. Upon this announcement, NOG shares fell in value.\r\nIf you have purchased Northern Oil &amp; Gas shares and wish to discuss your options, or if you are aware of any facts related to this investigation, or if you want to get more information—please contact us by telephone or online.', 'Northern Oil & Gas Securities', '', 'inherit', 'closed', 'closed', '', '36-revision-v1', '', '', '2016-12-11 23:36:50', '2016-12-11 23:36:50', '', 36, 'http://gus.com/2016/12/11/36-revision-v1/', 0, 'revision', '', 0),
(38, 1, '2016-12-11 23:37:31', '2016-12-11 23:37:31', 'Dan Gustafson was featured in the 2016 Minnesota Super Lawyers magazine for his work representing individuals who are civilly committed to the Minnesota Sex Offender Program (MSOP).  Gustafson Gluek took on the MSOP case on a pro bono basis as part of the Minnesota Chapter of the Federal Bar Association’s Pro Se Project.  Dan is referred to by his colleagues as “a smart, streetwise and skilled attorney who has no fear standing up to those in power.”  As Dan notes in the article, “regardless of what someone has done, they’re still entitled to the due process that the Constitution requires, and that is really the foundation of our system.”', 'Dan Gustafson Featured in Super Lawyers Magazine', '', 'publish', 'open', 'open', '', 'dan-gustafson-featured-in-super-lawyers-magazine', '', '', '2016-12-12 00:35:06', '2016-12-12 00:35:06', '', 0, 'http://gus.com/?p=38', 2, 'post', '', 0),
(39, 1, '2016-12-11 23:37:31', '2016-12-11 23:37:31', 'Dan Gustafson was featured in the 2016 Minnesota Super Lawyers magazine for his work representing individuals who are civilly committed to the Minnesota Sex Offender Program (MSOP).  Gustafson Gluek took on the MSOP case on a pro bono basis as part of the Minnesota Chapter of the Federal Bar Association’s Pro Se Project.  Dan is referred to by his colleagues as “a smart, streetwise and skilled attorney who has no fear standing up to those in power.”  As Dan notes in the article, “regardless of what someone has done, they’re still entitled to the due process that the Constitution requires, and that is really the foundation of our system.”', 'Dan Gustafson Featured in Super Lawyers Magazine', '', 'inherit', 'closed', 'closed', '', '38-revision-v1', '', '', '2016-12-11 23:37:31', '2016-12-11 23:37:31', '', 38, 'http://gus.com/2016/12/11/38-revision-v1/', 0, 'revision', '', 0),
(40, 1, '2016-12-11 23:38:25', '2016-12-11 23:38:25', 'Gustafson Gluek is investigating claims that Honest Company, and other Hain Celestial Brands misrepresented that their products do not have a chemical called Sodium Lauryl Sulfate or “SLS.”\r\nSLS is a known skin irritant. In order to market their products as “SLS free,” some companies have manufactured certain products with sodium coco sulfate or SCS instead. SCS, however, is a chemical largely made up of SLS. As a result, consumers have unwittingly paid higher prices for products claiming to be natural SLS-free products.\r\nAll consumers that purchased laundry detergent, dish soap, cleaners, body wash, shampoo, or other containing sodium coco sulfate from the following brands may be affected:\r\n<ul>\r\n 	<li>Honest</li>\r\n 	<li>Alba Botanica</li>\r\n 	<li>Avalon Organics</li>\r\n 	<li>Earth’s Best Organic</li>\r\n 	<li>JĀSÖN</li>\r\n 	<li>Ecos or Earth Friendly Products</li>\r\n 	<li>Yes To Carrots, Yes To Cucumbers</li>\r\n</ul>', '“SLS Free” Products', 'Gustafson Gluek is investigating claims that Honest Company, and other Hain Celestial Brands misrepresented that their products do not have a chemical called Sodium Lauryl Sulfate or “SLS.” SLS is a known skin irritant. In order to market their products as “SLS free,” some companies have manufactured certain products with sodium coco sulfate or SCS instead. SCS, however, is a chemical largely made up of SLS. As a result, consumers have unwittingly paid higher prices for products claiming to be natural SLS-free products.', 'publish', 'open', 'open', '', 'sls-free-products', '', '', '2016-12-12 00:26:37', '2016-12-12 00:26:37', '', 0, 'http://gus.com/?p=40', 3, 'post', '', 0),
(41, 1, '2016-12-11 23:38:25', '2016-12-11 23:38:25', 'Gustafson Gluek is investigating claims that Honest Company, and other Hain Celestial Brands misrepresented that their products do not have a chemical called Sodium Lauryl Sulfate or “SLS.”\r\nSLS is a known skin irritant. In order to market their products as “SLS free,” some companies have manufactured certain products with sodium coco sulfate or SCS instead. SCS, however, is a chemical largely made up of SLS. As a result, consumers have unwittingly paid higher prices for products claiming to be natural SLS-free products.\r\nAll consumers that purchased laundry detergent, dish soap, cleaners, body wash, shampoo, or other containing sodium coco sulfate from the following brands may be affected:\r\n<ul>\r\n 	<li>Honest</li>\r\n 	<li>Alba Botanica</li>\r\n 	<li>Avalon Organics</li>\r\n 	<li>Earth’s Best Organic</li>\r\n 	<li>JĀSÖN</li>\r\n 	<li>Ecos or Earth Friendly Products</li>\r\n 	<li>Yes To Carrots, Yes To Cucumbers</li>\r\n</ul>', '“SLS Free” Products', '', 'inherit', 'closed', 'closed', '', '40-revision-v1', '', '', '2016-12-11 23:38:25', '2016-12-11 23:38:25', '', 40, 'http://gus.com/2016/12/11/40-revision-v1/', 0, 'revision', '', 0),
(42, 1, '2016-12-11 23:58:16', '2016-12-11 23:58:16', 'Gustafson Gluek is investigating claims that Honest Company, and other Hain Celestial Brands misrepresented that their products do not have a chemical called Sodium Lauryl Sulfate or “SLS.”\r\nSLS is a known skin irritant. In order to market their products as “SLS free,” some companies have manufactured certain products with sodium coco sulfate or SCS instead. SCS, however, is a chemical largely made up of SLS. As a result, consumers have unwittingly paid higher prices for products claiming to be natural SLS-free products.\r\nAll consumers that purchased laundry detergent, dish soap, cleaners, body wash, shampoo, or other containing sodium coco sulfate from the following brands may be affected:\r\n<ul>\r\n 	<li>Honest</li>\r\n 	<li>Alba Botanica</li>\r\n 	<li>Avalon Organics</li>\r\n 	<li>Earth’s Best Organic</li>\r\n 	<li>JĀSÖN</li>\r\n 	<li>Ecos or Earth Friendly Products</li>\r\n 	<li>Yes To Carrots, Yes To Cucumbers</li>\r\n</ul>', '“SLS Free” Products', 'Gustafson Gluek is investigating claims that Honest Company, and other Hain Celestial Brands misrepresented that their products do not have a chemical called Sodium Lauryl Sulfate or “SLS.”\r\nSLS is a known skin irritant. In order to market their products as “SLS free,” some companies have manufactured certain products with sodium coco sulfate or SCS instead. SCS, however, is a chemical largely made up of SLS. As a result, consumers have unwittingly paid higher prices for products claiming to be natural SLS-free products.', 'inherit', 'closed', 'closed', '', '40-revision-v1', '', '', '2016-12-11 23:58:16', '2016-12-11 23:58:16', '', 40, 'http://gus.com/2016/12/11/40-revision-v1/', 0, 'revision', '', 0),
(43, 1, '2016-12-12 00:16:03', '2016-12-12 00:16:03', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2016-12-12 00:16:03', '2016-12-12 00:16:03', '', 1, 'http://gus.com/2016/12/12/1-revision-v1/', 0, 'revision', '', 0),
(44, 1, '2016-12-12 00:21:39', '2016-12-12 00:21:39', 'On Tuesday, Gustafson Gluek PLLC filed a complaint on behalf of purchasers of chicken alleging that the companies comprising 98% of the chicken meat produced in the United States conspired to fix prices for chicken. The complaint alleges a conspiracy dating back to 2008 that involved the restriction of production to increase prices. The complaint also seeks damages on behalf of a class of indirect purchasers of chicken, who purchased via a distributor.  If you purchased chicken via a distributor and would like to learn more about your potential claim, please contact us by telephone or online.', 'Poultry Price-Fixing', 'On Tuesday, Gustafson Gluek PLLC filed a complaint on behalf of purchasers of chicken alleging that the companies comprising 98% of the chicken meat produced in the United States conspired to fix prices for chicken. The complaint alleges a conspiracy dating back to 2008 that involved the restriction of production to increase prices. The complaint also seeks damages on behalf of a class of indirect purchasers of chicken, who purchased via a distributor.  If you purchased chicken via a distributor and would like to learn more about your potential claim, please contact us by telephone or online.', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2016-12-12 00:21:39', '2016-12-12 00:21:39', '', 34, 'http://gus.com/2016/12/12/34-revision-v1/', 0, 'revision', '', 0),
(45, 1, '2016-12-12 00:22:23', '2016-12-12 00:22:23', 'Gustafson Gluek is investigating claims on behalf of investors in Northern Oil &amp; Gas, Inc. (NYSE: NOG) regarding whether certain officers and/or directors may have breached their fiduciary duties and/or engaged in stock manipulation, in violation of federal securities laws.\r\nThe investigation concerns the following events, among others:\r\nOn August 11, 2016, Michael Reger informed Northern Oil &amp; Gas that the SEC had issued him a Wells Notice, a preliminary recommendation for enforcement action. The notice was in connection with the SEC’s investigation of 2012 trading patterns in Dakota Plains Holding, Inc., a company Mr. Reger helped start with several partners. On August 16, 2016, Northern Oil &amp; Gas fired Mr. Reger as CEO without severance. Upon this announcement, NOG shares fell in value.\r\nIf you have purchased Northern Oil &amp; Gas shares and wish to discuss your options, or if you are aware of any facts related to this investigation, or if you want to get more information—please contact us by telephone or online.', 'Northern Oil & Gas Securities', 'Gustafson Gluek is investigating claims on behalf of investors in Northern Oil &amp; Gas, Inc. (NYSE: NOG) regarding whether certain officers and/or directors may have breached their fiduciary duties and/or engaged in stock manipulation, in violation of federal securities laws.', 'inherit', 'closed', 'closed', '', '36-revision-v1', '', '', '2016-12-12 00:22:23', '2016-12-12 00:22:23', '', 36, 'http://gus.com/2016/12/12/36-revision-v1/', 0, 'revision', '', 0),
(46, 1, '2016-12-12 00:26:37', '2016-12-12 00:26:37', 'Gustafson Gluek is investigating claims that Honest Company, and other Hain Celestial Brands misrepresented that their products do not have a chemical called Sodium Lauryl Sulfate or “SLS.”\r\nSLS is a known skin irritant. In order to market their products as “SLS free,” some companies have manufactured certain products with sodium coco sulfate or SCS instead. SCS, however, is a chemical largely made up of SLS. As a result, consumers have unwittingly paid higher prices for products claiming to be natural SLS-free products.\r\nAll consumers that purchased laundry detergent, dish soap, cleaners, body wash, shampoo, or other containing sodium coco sulfate from the following brands may be affected:\r\n<ul>\r\n 	<li>Honest</li>\r\n 	<li>Alba Botanica</li>\r\n 	<li>Avalon Organics</li>\r\n 	<li>Earth’s Best Organic</li>\r\n 	<li>JĀSÖN</li>\r\n 	<li>Ecos or Earth Friendly Products</li>\r\n 	<li>Yes To Carrots, Yes To Cucumbers</li>\r\n</ul>', '“SLS Free” Products', 'Gustafson Gluek is investigating claims that Honest Company, and other Hain Celestial Brands misrepresented that their products do not have a chemical called Sodium Lauryl Sulfate or “SLS.” SLS is a known skin irritant. In order to market their products as “SLS free,” some companies have manufactured certain products with sodium coco sulfate or SCS instead. SCS, however, is a chemical largely made up of SLS. As a result, consumers have unwittingly paid higher prices for products claiming to be natural SLS-free products.', 'inherit', 'closed', 'closed', '', '40-revision-v1', '', '', '2016-12-12 00:26:37', '2016-12-12 00:26:37', '', 40, 'http://gus.com/2016/12/12/40-revision-v1/', 0, 'revision', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form`
#

DROP TABLE IF EXISTS `wp_rg_form`;


#
# Table structure of table `wp_rg_form`
#

CREATE TABLE `wp_rg_form` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_created` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_trash` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_rg_form`
#
INSERT INTO `wp_rg_form` ( `id`, `title`, `date_created`, `is_active`, `is_trash`) VALUES
(1, 'Free Consultation', '2016-12-05 19:09:36', 1, 0) ;

#
# End of data contents of table `wp_rg_form`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form_meta`
#

DROP TABLE IF EXISTS `wp_rg_form_meta`;


#
# Table structure of table `wp_rg_form_meta`
#

CREATE TABLE `wp_rg_form_meta` (
  `form_id` mediumint(8) unsigned NOT NULL,
  `display_meta` longtext COLLATE utf8mb4_unicode_ci,
  `entries_grid_meta` longtext COLLATE utf8mb4_unicode_ci,
  `confirmations` longtext COLLATE utf8mb4_unicode_ci,
  `notifications` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_rg_form_meta`
#
INSERT INTO `wp_rg_form_meta` ( `form_id`, `display_meta`, `entries_grid_meta`, `confirmations`, `notifications`) VALUES
(1, '{"title":"Free Consultation","description":"","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"Send My Story","imageUrl":""},"fields":[{"type":"text","id":1,"label":"Full Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Full Name","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","failed_validation":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"email","id":2,"label":"Email","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Email","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","failed_validation":"","productField":"","emailConfirmEnabled":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"phone","id":3,"label":"Phone","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"phoneFormat":"standard","formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Phone","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","form_id":"","failed_validation":"","productField":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"textarea","id":4,"label":"Your Story...","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Your Story...","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","failed_validation":"","productField":"","form_id":"","useRichTextEditor":false,"multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"pageNumber":1,"displayOnly":""}],"version":"2.1.1","id":1,"subLabelPlacement":"below","cssClass":"","enableHoneypot":true,"enableAnimation":false,"save":{"enabled":false,"button":{"type":"link","text":"Save and Continue Later"}},"limitEntries":false,"limitEntriesCount":"","limitEntriesPeriod":"","limitEntriesMessage":"","scheduleForm":false,"scheduleStart":"","scheduleStartHour":"","scheduleStartMinute":"","scheduleStartAmpm":"","scheduleEnd":"","scheduleEndHour":"","scheduleEndMinute":"","scheduleEndAmpm":"","schedulePendingMessage":"","scheduleMessage":"","requireLogin":false,"requireLoginMessage":"","useCurrentUserAsAuthor":true,"postContentTemplateEnabled":false,"postTitleTemplateEnabled":false,"postTitleTemplate":"","postContentTemplate":"","lastPageButton":null,"pagination":null,"firstPageCssClass":null,"notifications":{"5845bb70b6bde":{"id":"5845bb70b6bde","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}},"confirmations":{"5845bb70b6faa":{"id":"5845bb70b6faa","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}}}', '', '{"5845bb70b6faa":{"id":"5845bb70b6faa","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}}', '{"5845bb70b6bde":{"id":"5845bb70b6bde","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}}') ;

#
# End of data contents of table `wp_rg_form_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form_view`
#

DROP TABLE IF EXISTS `wp_rg_form_view`;


#
# Table structure of table `wp_rg_form_view`
#

CREATE TABLE `wp_rg_form_view` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `count` mediumint(8) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_rg_form_view`
#
INSERT INTO `wp_rg_form_view` ( `id`, `form_id`, `date_created`, `ip`, `count`) VALUES
(1, 1, '2016-12-05 19:15:01', '::1', 208),
(2, 1, '2016-12-05 19:15:01', '::1', 1),
(3, 1, '2016-12-06 19:36:21', '::1', 94),
(4, 1, '2016-12-06 19:36:21', '::1', 1),
(5, 1, '2016-12-07 21:14:31', '::1', 89),
(6, 1, '2016-12-08 21:15:29', '::1', 136),
(7, 1, '2016-12-08 21:15:29', '::1', 1),
(8, 1, '2016-12-09 21:16:19', '::1', 24),
(9, 1, '2016-12-11 20:21:09', '::1', 232) ;

#
# End of data contents of table `wp_rg_form_view`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_incomplete_submissions`
#

DROP TABLE IF EXISTS `wp_rg_incomplete_submissions`;


#
# Table structure of table `wp_rg_incomplete_submissions`
#

CREATE TABLE `wp_rg_incomplete_submissions` (
  `uuid` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` varchar(39) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_url` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `submission` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_rg_incomplete_submissions`
#

#
# End of data contents of table `wp_rg_incomplete_submissions`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead`
#

DROP TABLE IF EXISTS `wp_rg_lead`;


#
# Table structure of table `wp_rg_lead`
#

CREATE TABLE `wp_rg_lead` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `is_starred` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `ip` varchar(39) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_agent` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `currency` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` decimal(19,2) DEFAULT NULL,
  `transaction_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_fulfilled` tinyint(1) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `transaction_type` tinyint(1) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `payment_method` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_rg_lead`
#

#
# End of data contents of table `wp_rg_lead`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_detail`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail`;


#
# Table structure of table `wp_rg_lead_detail`
#

CREATE TABLE `wp_rg_lead_detail` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `field_number` float NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_field_number` (`lead_id`,`field_number`),
  KEY `lead_field_value` (`value`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_rg_lead_detail`
#

#
# End of data contents of table `wp_rg_lead_detail`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_detail_long`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail_long`;


#
# Table structure of table `wp_rg_lead_detail_long`
#

CREATE TABLE `wp_rg_lead_detail_long` (
  `lead_detail_id` bigint(20) unsigned NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`lead_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_rg_lead_detail_long`
#

#
# End of data contents of table `wp_rg_lead_detail_long`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_meta`
#

DROP TABLE IF EXISTS `wp_rg_lead_meta`;


#
# Table structure of table `wp_rg_lead_meta`
#

CREATE TABLE `wp_rg_lead_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lead_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`),
  KEY `meta_key` (`meta_key`(191)),
  KEY `form_id_meta_key` (`form_id`,`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_rg_lead_meta`
#

#
# End of data contents of table `wp_rg_lead_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_notes`
#

DROP TABLE IF EXISTS `wp_rg_lead_notes`;


#
# Table structure of table `wp_rg_lead_notes`
#

CREATE TABLE `wp_rg_lead_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `user_name` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_ci,
  `note_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_user_key` (`lead_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_rg_lead_notes`
#

#
# End of data contents of table `wp_rg_lead_notes`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(20, 2, 0),
(21, 2, 0),
(22, 2, 0),
(23, 2, 0),
(25, 2, 0),
(26, 2, 0),
(27, 2, 0),
(34, 1, 0),
(34, 3, 0),
(36, 1, 0),
(36, 4, 0),
(38, 1, 0),
(38, 5, 0),
(40, 1, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 4),
(2, 2, 'nav_menu', '', 0, 7),
(3, 3, 'category', '', 0, 1),
(4, 4, 'category', '', 0, 1),
(5, 5, 'category', '', 0, 1) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Menu 1', 'menu-1', 0),
(3, 'cat 1', 'cat-1', 0),
(4, 'Cat 2', 'cat-2', 0),
(5, 'cat 3', 'cat-3', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'highrank'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, 'wp_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', ''),
(13, 1, 'show_welcome_panel', '1'),
(14, 1, 'session_tokens', 'a:3:{s:64:"632c76952204a068f1ea31433e8264d514281118a332c1ba432f87b217dce951";a:4:{s:10:"expiration";i:1481501619;s:2:"ip";s:3:"::1";s:2:"ua";s:82:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:50.0) Gecko/20100101 Firefox/50.0";s:5:"login";i:1481328819;}s:64:"c3196fdc8a4f2910c058a24f4296dc5d8ba917ba25d8ad452edb02daae24ae27";a:4:{s:10:"expiration";i:1481501909;s:2:"ip";s:3:"::1";s:2:"ua";s:82:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:50.0) Gecko/20100101 Firefox/50.0";s:5:"login";i:1481329109;}s:64:"21721fe29f3d43d6150a93e7108d0a64fb2f787a49c9edcf482cb8cb3d242e62";a:4:{s:10:"expiration";i:1481671761;s:2:"ip";s:3:"::1";s:2:"ua";s:82:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:50.0) Gecko/20100101 Firefox/50.0";s:5:"login";i:1481498961;}}'),
(15, 1, 'wp_dashboard_quick_press_last_post_id', '31'),
(16, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(17, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:12:"add-post_tag";i:1;s:15:"add-post_format";}'),
(18, 1, 'wp_user-settings', 'editor=html'),
(19, 1, 'wp_user-settings-time', '1481499502'),
(20, 1, 'closedpostboxes_post', 'a:0:{}'),
(21, 1, 'metaboxhidden_post', 'a:6:{i:0;s:13:"trackbacksdiv";i:1;s:10:"postcustom";i:2;s:16:"commentstatusdiv";i:3;s:11:"commentsdiv";i:4;s:7:"slugdiv";i:5;s:9:"authordiv";}') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'highrank', '$P$B4DxgUyS33jdXPRpRoZ0eW4hQe/rHp/', 'highrank', 'garrett@1point21interactive.com', '', '2016-12-01 22:35:37', '', 0, 'highrank') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in
#

